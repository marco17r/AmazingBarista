package controller;

public class ABController extends AbstractController
{

}
